# -*- coding: utf-8 -*-
{
    'name': "source Sales",
    'summary': """source Sales""",
    'description': """source Sales""",
    'author': "Magdy, helcon",
    'website': "http://www.yourcompany.com",
    'category': 'sale',
    'version': '0.1',
    'depends': ['base', 'sale', 'stock'],
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/source_sales.xml',
    ],
}
